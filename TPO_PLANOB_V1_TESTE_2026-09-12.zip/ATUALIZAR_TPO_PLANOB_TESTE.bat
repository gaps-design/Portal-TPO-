@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title TPO Plano B - V1 Teste
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ATUALIZAR_TPO_PLANOB_TESTE.ps1"
if errorlevel 1 (
  echo.
  echo O teste terminou com erro.
  pause
)
endlocal
