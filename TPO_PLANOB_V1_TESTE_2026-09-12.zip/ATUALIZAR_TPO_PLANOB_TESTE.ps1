﻿$ErrorActionPreference = "Stop"

# ============================================================
# TPO PLANO B - V1 TESTE
# Sem Node / Sem Playwright
# NÃO altera o index.html de produção.
# ============================================================

$PortalTpo = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal TPO\index.html"
$Downloads = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Downloads"
$TempHtml = Join-Path (Split-Path $PortalTpo -Parent) "TPO_PLANOB_EXECUCAO_TESTE.html"
$LogDir = Join-Path (Split-Path $PortalTpo -Parent) "Logs_PlanoB_TPO"

function Log([string]$Mensagem) {
    $hora = Get-Date -Format "HH:mm:ss"
    Write-Host "[$hora] $Mensagem"
}

function MesAtualSigla {
    $meses = @("JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ")
    return $meses[(Get-Date).Month - 1]
}

function Liberar-ComObject($obj) {
    if ($null -ne $obj) {
        try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) } catch {}
    }
}

try {
    Clear-Host
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host "      TPO PLANO B - V1 TESTE (SEM NODE)" -ForegroundColor Cyan
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "SEGURANCA: esta versao NAO substitui o index.html." -ForegroundColor Yellow
    Write-Host "Ela apenas cria um HTML temporario e executa a analise." -ForegroundColor Yellow
    Write-Host ""

    if (!(Test-Path $PortalTpo)) {
        throw "Portal TPO nao encontrado: $PortalTpo"
    }
    if (!(Test-Path $Downloads)) {
        throw "Pasta de Downloads nao encontrada: $Downloads"
    }

    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

    Log "Procurando o relatorio TPO mais recente..."
    $arquivo = Get-ChildItem -Path $Downloads -Filter "relatorio-generico_*.xlsx" -File |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if (!$arquivo) {
        throw "Nenhum relatorio-generico_*.xlsx foi encontrado em $Downloads"
    }

    Log "Relatorio encontrado: $($arquivo.Name)"
    Log "Ultima alteracao: $($arquivo.LastWriteTime)"

    # Validação simples do nome/período. Não bloqueia o teste se o nome variar,
    # mas informa claramente o arquivo utilizado.
    if ($arquivo.Name -notmatch '^relatorio-generico_\d{2}_\d{2}_\d{4}_\d{2}_\d{2}_\d{4}( \(\d+\))?\.xlsx$') {
        Write-Host "AVISO: o nome do arquivo nao segue o padrao esperado do Athena." -ForegroundColor Yellow
    }

    Log "Abrindo Excel de forma invisivel..."
    $excel = $null; $wb = $null; $ws = $null; $range = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        $wb = $excel.Workbooks.Open($arquivo.FullName, 0, $true)
        $ws = $wb.Worksheets.Item(1)
        $range = $ws.UsedRange

        $linhas = [int]$range.Rows.Count
        $colunas = [int]$range.Columns.Count
        Log "Planilha lida: $linhas linhas x $colunas colunas."

        if ($linhas -lt 2 -or $colunas -lt 5) {
            throw "A planilha parece vazia ou incompleta ($linhas x $colunas)."
        }

        $dados = $range.Value2
        $sb = New-Object System.Text.StringBuilder
        for ($i = 1; $i -le $linhas; $i++) {
            $campos = New-Object System.Collections.Generic.List[string]
            for ($j = 1; $j -le $colunas; $j++) {
                $v = $dados[$i,$j]
                if ($null -eq $v) { $v = "" }
                $s = [string]$v
                # Garante uma linha TSV válida para o mesmo importador do portal.
                $s = $s -replace "`r`n|`n|`r", " "
                $campos.Add($s)
            }
            [void]$sb.AppendLine(($campos -join "`t"))
        }
        $texto = $sb.ToString()
        Log "Dados extraidos: $($texto.Length) caracteres."
    }
    finally {
        if ($wb) { try { $wb.Close($false) } catch {} }
        if ($excel) { try { $excel.Quit() } catch {} }
        Liberar-ComObject $range
        Liberar-ComObject $ws
        Liberar-ComObject $wb
        Liberar-ComObject $excel
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    }

    if ([string]::IsNullOrWhiteSpace($texto)) {
        throw "O Excel foi lido, mas o conteudo extraido ficou vazio."
    }

    Log "Preparando copia temporaria do Portal TPO..."
    $html = [System.IO.File]::ReadAllText($PortalTpo, [System.Text.Encoding]::UTF8)
    if ($html -notmatch 'function\s+analyzePasted\s*\(') {
        throw "A funcao analyzePasted nao foi encontrada no Portal TPO atual. O teste foi interrompido para evitar incompatibilidade."
    }
    if ($html -notmatch 'id="pasteBox"') {
        throw "O campo pasteBox nao foi encontrado no Portal TPO atual."
    }

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($texto)
    $b64 = [Convert]::ToBase64String($bytes)
    $mes = MesAtualSigla
    $relatorioNomeJs = ($arquivo.Name -replace '\\','\\\\' -replace "'", "\\'")

    $injecao = @"
<script id="tpoPlanoBInjector">
(function(){
  const B64 = '$b64';
  const MES = '$mes';
  const RELATORIO = '$relatorioNomeJs';
  function decodeUtf8Base64(b64){
    const bin=atob(b64); const bytes=new Uint8Array(bin.length);
    for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(bytes);
  }
  function status(txt, tipo){
    let el=document.getElementById('planob-status');
    if(!el){
      el=document.createElement('div'); el.id='planob-status';
      el.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;max-width:520px;padding:14px 16px;border-radius:12px;background:#111827;color:white;font:14px Arial;box-shadow:0 8px 30px rgba(0,0,0,.35);border:2px solid '+(tipo==='ok'?'#22c55e':tipo==='erro'?'#ef4444':'#f59e0b');
      document.body.appendChild(el);
    }
    el.innerHTML=txt;
  }
  function executar(){
    try{
      status('<b>PLANO B TPO</b><br>Carregando relatório: '+RELATORIO,'info');
      const botao=document.querySelector('button[data-page="update"]');
      if(botao) botao.click();
      const area=document.getElementById('pasteBox');
      const mes=document.getElementById('importMonth');
      if(!area || !mes || typeof analyzePasted!=='function') throw new Error('Estrutura de atualização do TPO não encontrada.');
      area.value=decodeUtf8Base64(B64);
      area.dispatchEvent(new Event('input',{bubbles:true}));
      area.dispatchEvent(new Event('change',{bubbles:true}));
      mes.value=MES;
      analyzePasted();
      setTimeout(function(){
        const msg=(document.getElementById('importMsg')?.innerText||'').trim();
        const preview=(document.getElementById('importPreview')?.innerText||'').trim();
        if(/erro|inválid|não reconhe|Cabeçalhos não encontrados/i.test(msg)){
          status('<b>PLANO B - ERRO NA ANÁLISE</b><br>'+msg.replace(/</g,'&lt;'),'erro');
        }else{
          status('<b>PLANO B - ANÁLISE CONCLUÍDA</b><br>Relatório: '+RELATORIO+'<br>Mês de destino: '+MES+'<br><br><b>MODO TESTE:</b> nenhum index.html de produção foi alterado.','ok');
        }
        console.log('[TPO PLANO B] importMsg:',msg); console.log('[TPO PLANO B] preview:',preview);
      },600);
    }catch(e){
      status('<b>PLANO B - FALHA</b><br>'+String(e.message||e),'erro');
      console.error(e);
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',()=>setTimeout(executar,700));
  else setTimeout(executar,700);
})();
</script>
"@

    if ($html -match '</body>') {
        $html = $html -replace '</body>', ($injecao + "`r`n</body>")
    } else {
        $html += $injecao
    }

    [System.IO.File]::WriteAllText($TempHtml, $html, (New-Object System.Text.UTF8Encoding($false)))
    Log "HTML temporario criado: $TempHtml"

    $logFile = Join-Path $LogDir ("teste_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")
    @(
      "TPO PLANO B - V1 TESTE",
      "Data: $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')",
      "Relatorio: $($arquivo.FullName)",
      "Linhas: $linhas",
      "Colunas: $colunas",
      "Mes destino: $mes",
      "HTML temporario: $TempHtml",
      "PRODUCAO ALTERADA: NAO"
    ) | Set-Content -Path $logFile -Encoding UTF8

    Log "Abrindo Portal TPO temporario..."
    Start-Process $TempHtml

    Write-Host ""
    Write-Host "==============================================" -ForegroundColor Green
    Write-Host "TESTE PREPARADO COM SUCESSO" -ForegroundColor Green
    Write-Host "==============================================" -ForegroundColor Green
    Write-Host "O navegador deve abrir sozinho na tela Atualizar base." -ForegroundColor White
    Write-Host "Confira os cards de Registros indicadores, Valvulas e Mes identificado." -ForegroundColor White
    Write-Host "" 
    Write-Host "IMPORTANTE: NAO clique em 'Atualizar mes' ainda." -ForegroundColor Yellow
    Write-Host "Este teste NAO substitui o index.html de producao." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Log: $logFile" -ForegroundColor DarkGray
}
catch {
    Write-Host ""
    Write-Host "ERRO NO PLANO B:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Read-Host "Pressione ENTER para fechar"
    exit 1
}
