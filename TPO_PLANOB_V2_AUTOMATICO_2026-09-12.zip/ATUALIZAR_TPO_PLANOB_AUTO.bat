@echo off
chcp 65001 >nul
setlocal
set "SRC=%~dp0ATUALIZAR_TPO_PLANOB_AUTO.ps1"
set "LOCALDIR=%LOCALAPPDATA%\Portal504_Automacao\TPO_PlanoB"
set "LOCALPS=%LOCALDIR%\ATUALIZAR_TPO_PLANOB_AUTO.ps1"

if not exist "%LOCALDIR%" mkdir "%LOCALDIR%" >nul 2>&1
copy /Y "%SRC%" "%LOCALPS%" >nul

rem Executa uma cópia LOCAL do script para evitar o aviso de segurança do arquivo na unidade N:.
powershell.exe -NoProfile -Command "Unblock-File -LiteralPath '%LOCALPS%' -ErrorAction SilentlyContinue; & '%LOCALPS%'"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo O Plano B terminou com erro. Veja a mensagem acima.
  pause
)
endlocal
exit /b %RC%
