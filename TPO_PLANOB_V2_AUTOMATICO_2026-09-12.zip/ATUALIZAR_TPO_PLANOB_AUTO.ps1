﻿$ErrorActionPreference = "Stop"

# ============================================================
# TPO PLANO B - V2 AUTOMATICO
# Sem Node / Sem Playwright
# Athena continua manual; do Excel em diante, automático.
# ============================================================

$PortalTpo = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Qualidade\Portal TPO\index.html"
$Downloads = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Downloads"
$PortalDir = Split-Path $PortalTpo -Parent
$TempHtml = Join-Path $PortalDir "TPO_PLANOB_EXECUCAO_AUTO.html"
$BackupDir = Join-Path $PortalDir "Backups_PlanoB_TPO"
$LogDir = Join-Path $PortalDir "Logs_PlanoB_TPO"
$TimeoutDownloadSeg = 120

function Log([string]$Mensagem, [string]$Cor = "Gray") {
    $hora = Get-Date -Format "HH:mm:ss"
    Write-Host "[$hora] $Mensagem" -ForegroundColor $Cor
}
function MesAtualSigla {
    $meses = @("JAN","FEV","MAR","ABR","MAI","JUN","JUL","AGO","SET","OUT","NOV","DEZ")
    return $meses[(Get-Date).Month - 1]
}
function Liberar-ComObject($obj) {
    if ($null -ne $obj) { try { [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) } catch {} }
}
function Validar-Index([string]$Arquivo) {
    if (!(Test-Path $Arquivo)) { throw "Index não encontrado: $Arquivo" }
    $fi = Get-Item $Arquivo
    if ($fi.Length -lt 100000) { throw "O index gerado parece incompleto ($($fi.Length) bytes)." }
    $conteudo = [System.IO.File]::ReadAllText($Arquivo, [System.Text.Encoding]::UTF8)
    if ($conteudo -notmatch 'PORTAL TPO|Portal TPO') { throw "O arquivo gerado não parece ser o Portal TPO." }
    if ($conteudo -notmatch '/\*DATA_START\*/let DATA=') { throw "Bloco DATA_START não encontrado no index gerado." }
    if ($conteudo -notmatch '/\*DATA_END\*/') { throw "Bloco DATA_END não encontrado no index gerado." }
    return $conteudo
}
function Periodo-Esperado {
    $hoje = (Get-Date).Date
    $primeiroMes = Get-Date -Year $hoje.Year -Month $hoje.Month -Day 1
    $inicio = $primeiroMes.AddDays(-1)
    return @{ Inicio=$inicio; PrimeiroMes=$primeiroMes; Hoje=$hoje }
}
function Validar-PeriodoNome($arquivo) {
    $m = [regex]::Match($arquivo.Name, '^relatorio-generico_(\d{2})_(\d{2})_(\d{4})_(\d{2})_(\d{2})_(\d{4})(?: \(\d+\))?\.xlsx$')
    if (!$m.Success) { throw "Nome do relatório fora do padrão esperado: $($arquivo.Name)" }
    $de = [datetime]::ParseExact(($m.Groups[1].Value + '/' + $m.Groups[2].Value + '/' + $m.Groups[3].Value),'dd/MM/yyyy',$null)
    $ate = [datetime]::ParseExact(($m.Groups[4].Value + '/' + $m.Groups[5].Value + '/' + $m.Groups[6].Value),'dd/MM/yyyy',$null)
    $p = Periodo-Esperado
    if ($de.Date -ne $p.Inicio.Date -or $ate.Date -ne $p.Hoje.Date) {
        throw "PERÍODO BLOQUEADO. Esperado $($p.Inicio.ToString('dd/MM/yyyy')) a $($p.Hoje.ToString('dd/MM/yyyy')); arquivo indica $($de.ToString('dd/MM/yyyy')) a $($ate.ToString('dd/MM/yyyy')). Produção NÃO foi alterada."
    }
    Log "Período validado: $($de.ToString('dd/MM/yyyy')) a $($ate.ToString('dd/MM/yyyy'))." "Green"
}

$excel=$null; $wb=$null; $ws=$null; $range=$null
$logFile=$null
try {
    Clear-Host
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "       TPO PLANO B - V2 AUTOMÁTICO (SEM NODE)" -ForegroundColor Cyan
    Write-Host "====================================================" -ForegroundColor Cyan
    Write-Host "Athena: manual | Excel -> Portal -> Backup -> Produção: automático" -ForegroundColor White
    Write-Host ""

    if (!(Test-Path $PortalTpo)) { throw "Portal TPO não encontrado: $PortalTpo" }
    if (!(Test-Path $Downloads)) { throw "Pasta de Downloads não encontrada: $Downloads" }
    New-Item -ItemType Directory -Force -Path $BackupDir,$LogDir | Out-Null

    $logFile = Join-Path $LogDir ("auto_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")
    Start-Transcript -Path $logFile -Append | Out-Null

    Log "Localizando o relatório TPO mais recente..." "Cyan"
    $arquivo = Get-ChildItem -Path $Downloads -Filter "relatorio-generico_*.xlsx" -File |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (!$arquivo) { throw "Nenhum relatorio-generico_*.xlsx encontrado em $Downloads" }
    Log "Relatório encontrado: $($arquivo.Name)" "Green"
    Validar-PeriodoNome $arquivo

    Log "Validando Portal TPO atual..." "Cyan"
    $html = Validar-Index $PortalTpo
    foreach($item in @('function analyzePasted','function applyPending','function generateIndex','id="pasteBox"','id="importMonth"')) {
        if ($html -notlike "*$item*") { throw "Estrutura necessária não encontrada no Portal TPO: $item" }
    }

    Log "Abrindo Excel de forma invisível..." "Cyan"
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $wb = $excel.Workbooks.Open($arquivo.FullName, 0, $true)
    $ws = $wb.Worksheets.Item(1)
    $range = $ws.UsedRange
    $linhas=[int]$range.Rows.Count; $colunas=[int]$range.Columns.Count
    Log "Planilha: $linhas linhas x $colunas colunas." "Green"
    if ($linhas -lt 100 -or $colunas -lt 10) { throw "Planilha parece incompleta ($linhas x $colunas)." }

    $dados=$range.Value2
    $sb=New-Object System.Text.StringBuilder
    for($i=1;$i -le $linhas;$i++){
        $campos=New-Object System.Collections.Generic.List[string]
        for($j=1;$j -le $colunas;$j++){
            $v=$dados[$i,$j]; if($null -eq $v){$v=""}
            $s=([string]$v) -replace "`r`n|`n|`r"," "
            $campos.Add($s)
        }
        [void]$sb.AppendLine(($campos -join "`t"))
    }
    $texto=$sb.ToString()
    if ([string]::IsNullOrWhiteSpace($texto)) { throw "Conteúdo extraído do Excel ficou vazio." }

    $wb.Close($false); $excel.Quit()
    Liberar-ComObject $range; Liberar-ComObject $ws; Liberar-ComObject $wb; Liberar-ComObject $excel
    $range=$null;$ws=$null;$wb=$null;$excel=$null
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()

    Log "Preparando execução automática no motor do próprio Portal TPO..." "Cyan"
    $b64=[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($texto))
    $mes=MesAtualSigla
    $relatorioNomeJs=($arquivo.Name -replace '\\','\\\\' -replace "'", "\\'")

    # Marca o instante a partir do qual um novo index baixado será aceito.
    $inicioGeracao = Get-Date

    $injecao=@"
<script id="tpoPlanoBInjectorAuto">
(function(){
 const B64='$b64', MES='$mes', RELATORIO='$relatorioNomeJs';
 function dec(b){const x=atob(b),u=new Uint8Array(x.length);for(let i=0;i<x.length;i++)u[i]=x.charCodeAt(i);return new TextDecoder('utf-8').decode(u)}
 function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
 function st(t,k){let e=document.getElementById('planob-status');if(!e){e=document.createElement('div');e.id='planob-status';e.style.cssText='position:fixed;right:18px;bottom:18px;z-index:999999;max-width:560px;padding:14px 16px;border-radius:12px;background:#111827;color:white;font:14px Arial;box-shadow:0 8px 30px rgba(0,0,0,.35);border:2px solid #f59e0b';document.body.appendChild(e)}e.style.borderColor=k==='ok'?'#22c55e':k==='erro'?'#ef4444':'#f59e0b';e.innerHTML=t}
 async function wait(ms){return new Promise(r=>setTimeout(r,ms))}
 async function run(){
  try{
   st('<b>PLANO B TPO V2</b><br>Carregando '+esc(RELATORIO),'info');
   document.querySelector('button[data-page="update"]')?.click(); await wait(300);
   const area=document.getElementById('pasteBox'), sel=document.getElementById('importMonth');
   if(!area||!sel||typeof analyzePasted!=='function'||typeof applyPending!=='function'||typeof generateIndex!=='function') throw new Error('Estrutura de atualização incompatível.');
   area.value=dec(B64); area.dispatchEvent(new Event('input',{bubbles:true})); area.dispatchEvent(new Event('change',{bubbles:true}));
   sel.value=MES; analyzePasted(); await wait(500);
   let msg=(document.getElementById('importMsg')?.innerText||'').trim();
   if(/erro|inválid|não reconhe|Cabeçalhos não encontrados/i.test(msg)) throw new Error('Análise bloqueada: '+msg);
   // O analisador pode inferir AGO por causa do dia de sobreposição. O destino é SEMPRE o mês atual.
   sel.value=MES;
   const originalConfirm=window.confirm;
   let confirmOk=false;
   window.confirm=function(m){
      const ok=new RegExp('^ATUALIZAR\\s+'+MES+'\\?','i').test(String(m||''));
      if(ok){confirmOk=true;return true}
      return false;
   };
   try{applyPending()} finally{window.confirm=originalConfirm}
   await wait(700);
   msg=(document.getElementById('importMsg')?.innerText||'').trim();
   if(!confirmOk) throw new Error('A confirmação de atualização não correspondeu ao mês '+MES+'.');
   if(/bloqueada|cancelada|erro|inválid|falha/i.test(msg)) throw new Error('Atualização bloqueada: '+msg);
   if(!(new RegExp('\\b'+MES+'\\b','i').test(msg) && /atualizado com segurança|foi atualizado/i.test(msg))) throw new Error('O Portal não confirmou a atualização segura: '+msg);
   st('<b>PLANO B V2</b><br>'+esc(msg)+'<br><br>Gerando novo index.html...','info');
   generateIndex();
   st('<b>PLANO B V2</b><br>Mês '+MES+' atualizado no motor do portal.<br>Novo index.html enviado para Downloads.<br><br>Aguardando validação e substituição pelo PowerShell...','ok');
  }catch(e){st('<b>PLANO B V2 - BLOQUEADO</b><br>'+esc(e.message||e),'erro');console.error(e)}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(run,700));else setTimeout(run,700);
})();
</script>
"@
    if($html -match '</body>'){$html=$html -replace '</body>',($injecao+"`r`n</body>")}else{$html+=$injecao}
    [System.IO.File]::WriteAllText($TempHtml,$html,(New-Object System.Text.UTF8Encoding($false)))
    Log "HTML temporário pronto." "Green"

    Log "Abrindo Portal TPO automático..." "Cyan"
    Start-Process $TempHtml

    Log "Aguardando o novo index.html aparecer em Downloads (até $TimeoutDownloadSeg s)..." "Cyan"
    $gerado=$null
    $limite=(Get-Date).AddSeconds($TimeoutDownloadSeg)
    while((Get-Date) -lt $limite){
        $gerado=Get-ChildItem -Path $Downloads -Filter "index*.html" -File -ErrorAction SilentlyContinue |
          Where-Object { $_.LastWriteTime -ge $inicioGeracao.AddSeconds(-3) -and $_.Length -gt 100000 } |
          Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if($gerado){break}
        Start-Sleep -Milliseconds 700
    }
    if(!$gerado){throw "O Portal não gerou um novo index.html dentro de $TimeoutDownloadSeg segundos. Produção NÃO foi alterada. Verifique a mensagem exibida no navegador."}
    Log "Index gerado encontrado: $($gerado.FullName)" "Green"

    $novoConteudo=Validar-Index $gerado.FullName
    $p=Periodo-Esperado
    $periodoEsperadoNoPortal = "Atualizado por relatório • $($p.PrimeiroMes.ToString('dd/MM/yyyy')) a $($p.Hoje.ToString('dd/MM/yyyy'))"
    if($novoConteudo -notlike "*$periodoEsperadoNoPortal*"){
        throw "O index gerado não contém a origem esperada do mês atual ($periodoEsperadoNoPortal). Produção NÃO foi alterada."
    }
    Log "Conteúdo do novo index validado." "Green"

    $backup=Join-Path $BackupDir ("index_"+(Get-Date -Format "yyyyMMdd_HHmmss")+".html")
    Copy-Item -LiteralPath $PortalTpo -Destination $backup -Force
    [void](Validar-Index $backup)
    Log "Backup criado: $backup" "Green"

    $tempDestino=Join-Path $PortalDir "index.__novo__.html"
    $oldTemp=Join-Path $PortalDir "index.__anterior__.html"
    Remove-Item $tempDestino,$oldTemp -Force -ErrorAction SilentlyContinue
    Copy-Item -LiteralPath $gerado.FullName -Destination $tempDestino -Force
    [void](Validar-Index $tempDestino)

    if(Test-Path $PortalTpo){Move-Item -LiteralPath $PortalTpo -Destination $oldTemp -Force}
    try{
        Move-Item -LiteralPath $tempDestino -Destination $PortalTpo -Force
        [void](Validar-Index $PortalTpo)
        Remove-Item $oldTemp -Force -ErrorAction SilentlyContinue
    }catch{
        if(!(Test-Path $PortalTpo) -and (Test-Path $oldTemp)){Move-Item $oldTemp $PortalTpo -Force}
        throw
    }

    Remove-Item -LiteralPath $gerado.FullName -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $TempHtml -Force -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "       TPO ATUALIZADO COM SUCESSO - PLANO B" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "Relatório: $($arquivo.Name)" -ForegroundColor White
    Write-Host "Mês atualizado: $mes" -ForegroundColor White
    Write-Host "Backup: $backup" -ForegroundColor DarkGray
    Write-Host "Produção: $PortalTpo" -ForegroundColor Cyan
    Write-Host ""
    Log "Processo concluído. A janela será fechada em 8 segundos." "Green"
    Start-Sleep -Seconds 8
}
catch{
    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host "        ATUALIZAÇÃO BLOQUEADA - PRODUÇÃO SEGURA" -ForegroundColor Red
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Nenhum index novo deve ser colocado em produção quando esta mensagem aparecer." -ForegroundColor Yellow
    Write-Host "Log: $logFile" -ForegroundColor DarkGray
    Read-Host "Pressione ENTER para fechar"
    exit 1
}
finally{
    if($wb){try{$wb.Close($false)}catch{}}
    if($excel){try{$excel.Quit()}catch{}}
    Liberar-ComObject $range; Liberar-ComObject $ws; Liberar-ComObject $wb; Liberar-ComObject $excel
    try{Stop-Transcript | Out-Null}catch{}
}
